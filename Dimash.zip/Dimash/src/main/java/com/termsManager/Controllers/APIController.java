package com.termsManager.Controllers;
import com.termsManager.DB.Term;
import com.termsManager.Repositories.TermRepository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/term")
public class APIController {
    private final TermRepository termRepository;

    public APIController(TermRepository termRepository) {
        this.termRepository = termRepository;
    }

    @GetMapping
    public List<Term> getActiveTasks(){
        return termRepository.findAll();
    }

    record NewTaskRequest(
            String name,
            LocalDate deadline,
            String description
    ) {

    }
    record UpdateTaskRequest(
            String name,
            LocalDate deadline,
            String description

    ) {

    }
    @PostMapping
    public void addTerm(@RequestBody NewTaskRequest request) {
        Term term = new Term();
        term.setName(request.name);
        term.setDeadline(request.deadline);
        term.setDescription(request.description);
        termRepository.save(term);
    }
    @DeleteMapping("{taskId}")
    public void deleteTask(@PathVariable("taskId") Integer id) {
        termRepository.deleteById(id);
    }
    @PutMapping("{customerId}")
    public void updateCustomer(@PathVariable("customerId") Integer id,
                               @RequestBody UpdateTaskRequest request){
        Term term = termRepository.getReferenceById(id);
        if(request.name != null) term.setName(request.name);
        if(request.deadline != null) term.setDeadline(request.deadline);
        if(request.description != null) term.setDescription(request.description);
        termRepository.save(term);
    }
}
