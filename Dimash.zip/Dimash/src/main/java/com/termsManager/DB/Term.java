package com.termsManager.DB;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Term {
    @Id
    @SequenceGenerator(
            name = "term_id_sequence",
            sequenceName = "term_id_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "term_id_sequence"
    )
    private Integer id;
    private String name;
    private LocalDate deadline;
    @Column(name = "description", length = 300)
    private String description;
}
